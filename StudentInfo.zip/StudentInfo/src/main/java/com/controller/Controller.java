package com.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.entity.studentinfo;
import com.service.Service;
@RestController
public class Controller {
      @Autowired  
	 Service ss;
	@PostMapping("/insert")
      public boolean insertstudname(@RequestBody studentinfo student ) {
    	boolean inserted =  ss.insertstudname(student);
		return inserted;
      }
	@GetMapping("/all")
	public List<studentinfo> getstudinfo() {
		List<studentinfo> l=ss.getstudinfo();
		return l;
	}
	@GetMapping("/select/{id}")
	public studentinfo selectrecord(@PathVariable int id) {
		studentinfo stud =	ss.selectrecord(id);
		return stud;
	}
	@DeleteMapping("/Delete/{id}")
	public boolean deleteRecord(@PathVariable int id) {
	boolean stud =	ss.deleteRecord(id);
	return stud;
	
	}
	@PutMapping("/update")
	public boolean updatedata (@RequestBody studentinfo s){
	boolean inserted =	ss.updatedata(s);
		return inserted;
	}
}
