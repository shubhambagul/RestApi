package com.dao;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.entity.studentinfo;
@Repository
public class Dao {
@Autowired
	SessionFactory sf;

public boolean insertstudname(studentinfo student) {
	Session session = sf.openSession();
    Transaction tr=session.beginTransaction();
    System.out.println(student);
	session.save(student);
	tr.commit();
	
	session.close();
	return true;
}

public List<studentinfo> getstudinfo() {
	Session session = sf.openSession();
	Criteria criteria = session.createCriteria(studentinfo.class);
	  List<studentinfo> l =  criteria.list();
	session.close();
	return l;
}

public studentinfo selectrecord(int id) {
	Session session = sf.openSession();
	studentinfo stud = session.get(studentinfo.class, id);
	session.close();
	return stud;
}

public boolean deleteRecord(int id) {
	Session session = sf.openSession();
	Transaction tr = session.beginTransaction();
	studentinfo stud = session.get(studentinfo.class, id);
	session.delete(stud);
	tr.commit();
	session.close();
	return true;
	
}

public boolean updatedata(studentinfo s) {
	Session session = sf.openSession();
	Transaction tr = session.beginTransaction();
	System.out.println(s);
	session.update(s);
	tr.commit();
	session.close();
	return true;
}
	

}
