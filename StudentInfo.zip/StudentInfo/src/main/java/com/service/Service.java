package com.service;



import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.dao.Dao;
import com.entity.studentinfo;
@org.springframework.stereotype.Service
public class Service {
      @Autowired
	Dao dd;

	public boolean insertstudname(studentinfo student) {
		 return dd.insertstudname(student);
		
	}

	public List<studentinfo> getstudinfo() {
		return dd.getstudinfo();
	}

	public studentinfo selectrecord(int id) {
		return dd.selectrecord(id);
		
	}

	public boolean deleteRecord(int id) {
		return dd.deleteRecord(id);
	}

	public boolean updatedata(studentinfo s) {
		// TODO Auto-generated method stub
	boolean update =dd.updatedata(s);
	return update;
	}
	

	

}
